export const en = {
  APP: {
    heading: {
      intro: 'Awesome',
      appName: 'GUEST BOOK',
      postText: 'supported by React/Redux/Firebase',
    },
  },
  USER: {
    add: 'Add',
    clear: 'Clear',
    edit: 'Edit',
    delete: 'Delete',
    confirm: 'Confirm',
    cancel: 'Cancel',
  },
};
