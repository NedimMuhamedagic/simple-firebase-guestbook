// @flow
export const BUFFER_SLIDING_AMT = 10;
export const LOCAL_STORAGE_KEY = '@simpleguestbook';
